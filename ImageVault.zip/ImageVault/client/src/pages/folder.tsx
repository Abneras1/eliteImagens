import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useApp } from "@/contexts/AppContext";
import { Upload, Search, Share2, ChevronDown, Home, MoreVertical, Eye } from "lucide-react";
import ShareDialog from "@/components/ShareDialog";
import ImagePreview from "@/components/ImagePreview";
import UploadDropzone from "@/components/UploadDropzone";
import { formatBytes, formatDate } from "@/lib/utils";

export default function Folder() {
  const [, params] = useRoute('/folders/:id');
  const folderId = parseInt(params?.id || '0');
  const [searchQuery, setSearchQuery] = useState("");

  const { 
    setSharedContentType, 
    setSharedContentId, 
    setShareDialogOpen, 
    setShareUrl,
    setImagePreviewOpen,
    setCurrentImage,
    setUploadDialogOpen,
    setCurrentFolderId
  } = useApp();

  const { data: folder, isLoading: folderLoading } = useQuery({ 
    queryKey: [`/api/folders/${folderId}`],
    enabled: !!folderId
  });

  const { data: images, isLoading: imagesLoading } = useQuery({ 
    queryKey: [`/api/folders/${folderId}/images`],
    enabled: !!folderId
  });

  const isLoading = folderLoading || imagesLoading;

  const handleShare = () => {
    setShareUrl("");
    setSharedContentType("folder");
    setSharedContentId(folderId);
    setShareDialogOpen(true);
  };

  const handleUpload = () => {
    setCurrentFolderId(folderId);
    setUploadDialogOpen(true);
  };

  const handleImageClick = (image: any) => {
    setCurrentImage(image);
    setImagePreviewOpen(true);
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Breadcrumb className="mb-6">
          <BreadcrumbItem>
            <BreadcrumbLink href="/">
              <Home className="h-4 w-4 mr-1" />
              <span>Home</span>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/">My Folders</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <Skeleton className="h-4 w-20" />
          </BreadcrumbItem>
        </Breadcrumb>

        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 space-y-4 sm:space-y-0">
          <Skeleton className="h-8 w-48" />
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
            <Skeleton className="h-10 w-48" />
            <Skeleton className="h-10 w-24" />
            <Skeleton className="h-10 w-24" />
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array(10).fill(0).map((_, i) => (
            <Skeleton key={i} className="aspect-square w-full rounded" />
          ))}
        </div>
      </div>
    );
  }

  const filteredImages = images?.filter((image: any) => 
    image.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Helmet>
        <title>{folder ? `${folder.name} - Elite Imagens` : 'Pasta - Elite Imagens'}</title>
        <meta name="description" content={`Visualize imagens na pasta ${folder?.name}`} />
      </Helmet>

      <Breadcrumb className="mb-6">
        <BreadcrumbItem>
          <BreadcrumbLink href="/">
            <Home className="h-4 w-4 mr-1" />
            <span>Início</span>
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbSeparator />
        <BreadcrumbItem>
          <BreadcrumbLink href="/">My Folders</BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbSeparator />
        <BreadcrumbItem>
          <span className="font-medium text-gray-800">{folder?.name}</span>
        </BreadcrumbItem>
      </Breadcrumb>

      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 space-y-4 sm:space-y-0">
        <h2 className="text-2xl font-semibold text-gray-800">{folder?.name}</h2>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Buscar imagens..."
              className="pl-10 pr-4 py-2 w-full sm:w-auto"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button onClick={handleShare}>
            <Share2 className="h-5 w-5 mr-2" />
            Compartilhar
          </Button>
          <Button onClick={handleUpload}>
            <Upload className="h-5 w-5 mr-2" />
            Enviar
          </Button>
        </div>
      </div>

      {filteredImages.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Upload className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-800 mb-2">Nenhuma imagem encontrada</h3>
            <p className="text-gray-500 mb-4">
              {searchQuery 
                ? "Nenhuma imagem corresponde à sua busca." 
                : "Esta pasta está vazia. Envie algumas imagens para começar."}
            </p>
            {!searchQuery && (
              <Button onClick={handleUpload}>
                <Upload className="h-5 w-5 mr-2" />
                Enviar Arquivos
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredImages.map((image: any) => (
            <div key={image.id} className="group relative">
              <div 
                className="aspect-square w-full overflow-hidden rounded-md bg-gray-100 border border-gray-200"
                onClick={() => handleImageClick(image)}
              >
                <img
                  src={image.path.startsWith('/uploads') ? image.path : `/uploads/${image.path.split('/').pop()}`}
                  alt={image.name}
                  className="h-full w-full object-cover object-center cursor-pointer hover:opacity-90 transition-opacity"
                />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black bg-opacity-30">
                  <Button 
                    variant="secondary" 
                    size="icon" 
                    className="h-9 w-9"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleImageClick(image);
                    }}
                  >
                    <Eye className="h-5 w-5" />
                  </Button>
                </div>
              </div>
              <div className="mt-2 flex items-center justify-between">
                <div className="max-w-[80%]">
                  <p className="text-sm font-medium text-gray-900 truncate" title={image.name}>
                    {image.name}
                  </p>
                  <p className="text-xs text-gray-500">{formatBytes(image.size)}</p>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreVertical className="h-4 w-4" />
                      <span className="sr-only">Mais opções</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleImageClick(image)}>
                      Visualizar
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => {
                        setShareUrl("");
                        setSharedContentType("image");
                        setSharedContentId(image.id);
                        setShareDialogOpen(true);
                      }}
                    >
                      Compartilhar
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modals */}
      <ShareDialog />
      <ImagePreview />
      <UploadDropzone />
    </div>
  );
}