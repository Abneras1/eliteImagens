import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { Helmet } from "react-helmet";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Home, Download, ArrowLeft, X, Info, Eye } from "lucide-react";
import { formatBytes, formatDate } from "@/lib/utils";

// Página para visualizar conteúdo compartilhado via link
export default function Shared() {
  const [, params] = useRoute('/share/:token');
  const token = params?.token;
  const [content, setContent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentImage, setCurrentImage] = useState<any>(null);
  const [showImageDialog, setShowImageDialog] = useState(false);

  useEffect(() => {
    if (!token) return;

    const fetchSharedContent = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/share/${token}`);
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Não foi possível carregar o conteúdo compartilhado');
        }
        
        const data = await response.json();
        setContent(data);
        setError(null);
      } catch (err: any) {
        setError(err.message || 'Ocorreu um erro ao carregar o conteúdo');
      } finally {
        setLoading(false);
      }
    };

    fetchSharedContent();
  }, [token]);

  const handleDownload = (path: string, name: string) => {
    const link = document.createElement('a');
    link.href = path.startsWith('/uploads') ? path : `/uploads/${path.split('/').pop()}`;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const openImageViewer = (image: any) => {
    setCurrentImage(image);
    setShowImageDialog(true);
  };
  
  const getImagePath = (path: string) => {
    return path.startsWith('/uploads') ? path : `/uploads/${path.split('/').pop()}`;
  };

  // Estado de carregamento
  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-center items-center mt-10">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
        <p className="text-center mt-4 text-gray-600">Carregando conteúdo compartilhado...</p>
      </div>
    );
  }

  // Estado de erro
  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Card className="mt-8">
          <CardContent className="p-8 text-center">
            <div className="rounded-full bg-red-100 p-3 mx-auto w-16 h-16 flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Erro ao carregar conteúdo</h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <Link href="/">
              <Button className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Voltar para página inicial
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Estado de conteúdo não encontrado
  if (!content) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Card className="mt-8">
          <CardContent className="p-8 text-center">
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Conteúdo não encontrado</h2>
            <p className="text-gray-600 mb-6">O conteúdo que você está procurando não existe ou foi removido.</p>
            <Link href="/">
              <Button className="gap-2">
                <Home className="h-4 w-4" />
                Página inicial
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Renderizar uma pasta compartilhada
  if (content.type === 'folder') {
    const { folder, images } = content.data;

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Helmet>
          <title>{folder.name} - Conteúdo Compartilhado - Elite Imagens</title>
          <meta name="description" content={`Conteúdo compartilhado da pasta ${folder.name}`} />
        </Helmet>
        
        <Breadcrumb className="mb-6">
          <BreadcrumbItem>
            <BreadcrumbLink href="/">
              <Home className="h-4 w-4 mr-1" />
              <span>Início</span>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <span>Conteúdo Compartilhado</span>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <span className="font-medium text-gray-800">{folder.name}</span>
          </BreadcrumbItem>
        </Breadcrumb>
        
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center">
            <div className="bg-amber-100 p-3 rounded-full mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-amber-600" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M2 6a2 2 0 012-2h5l2 2h5a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
              </svg>
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-gray-800">{folder.name}</h1>
              <p className="text-sm text-gray-500">Pasta compartilhada • {images.length} {images.length === 1 ? 'imagem' : 'imagens'}</p>
            </div>
          </div>
        </div>
        
        {images.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-300 mx-auto mb-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
              </svg>
              <h3 className="text-lg font-medium text-gray-800 mb-2">Esta pasta está vazia</h3>
              <p className="text-gray-500 mb-4">
                Esta pasta não contém nenhuma imagem.
              </p>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {images.map((image: any) => (
                <div key={image.id} className="group relative">
                  <div className="aspect-square w-full overflow-hidden rounded-md bg-gray-100 border border-gray-200">
                    <img
                      src={getImagePath(image.path)}
                      alt={image.name}
                      className="h-full w-full object-cover object-center cursor-pointer"
                      onClick={() => openImageViewer(image)}
                    />
                    <div className="absolute inset-0 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black bg-opacity-40">
                      <Button 
                        variant="secondary" 
                        size="icon" 
                        className="h-9 w-9"
                        onClick={() => openImageViewer(image)}
                      >
                        <Eye className="h-5 w-5" />
                      </Button>
                      <Button 
                        variant="secondary" 
                        size="icon" 
                        className="h-9 w-9"
                        onClick={() => handleDownload(image.path, image.name)}
                      >
                        <Download className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                  <div className="mt-2">
                    <p className="text-sm font-medium text-gray-900 truncate" title={image.name}>
                      {image.name}
                    </p>
                    <div className="flex justify-between items-center">
                      <p className="text-xs text-gray-500">{formatBytes(image.size)}</p>
                      {image.description && (
                        <div className="text-xs text-blue-500 flex items-center cursor-pointer hover:text-blue-600" 
                          onClick={() => openImageViewer(image)}
                          title="Ver descrição">
                          <Info className="h-3 w-3 mr-1" />
                          <span>Info</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <Dialog open={showImageDialog} onOpenChange={setShowImageDialog}>
              <DialogContent className="max-w-4xl p-0 overflow-hidden">
                <DialogHeader className="p-4 border-b">
                  <div className="flex justify-between items-center">
                    <DialogTitle className="text-lg">{currentImage?.name}</DialogTitle>
                    <Button variant="ghost" size="icon" onClick={() => setShowImageDialog(false)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <DialogDescription className="text-xs text-gray-500 mt-1">
                    {currentImage?.createdAt && (
                      <>Adicionado em {formatDate(currentImage.createdAt)} • {formatBytes(currentImage.size)}</>
                    )}
                  </DialogDescription>
                </DialogHeader>
                
                <div className="bg-black flex items-center justify-center p-4 max-h-[calc(100vh-200px)]">
                  {currentImage && (
                    <img 
                      src={getImagePath(currentImage.path)}
                      alt={currentImage.name}
                      className="max-h-full max-w-full object-contain"
                    />
                  )}
                </div>
                
                {currentImage?.description && (
                  <div className="p-4 border-t">
                    <h3 className="text-sm font-medium text-gray-700 mb-1">Descrição</h3>
                    <p className="text-sm text-gray-600">{currentImage.description}</p>
                  </div>
                )}
                
                <DialogFooter className="p-4 border-t">
                  <Button 
                    variant="outline"
                    onClick={() => currentImage && handleDownload(currentImage.path, currentImage.name)}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Baixar
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </>
        )}
      </div>
    );
  }

  // Renderizar uma imagem compartilhada
  if (content.type === 'image') {
    const image = content.data;

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Helmet>
          <title>{image.name} - Imagem Compartilhada - Elite Imagens</title>
          <meta name="description" content={`Imagem compartilhada: ${image.name}`} />
        </Helmet>
        
        <Breadcrumb className="mb-6">
          <BreadcrumbItem>
            <BreadcrumbLink href="/">
              <Home className="h-4 w-4 mr-1" />
              <span>Início</span>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <span>Conteúdo Compartilhado</span>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <span className="font-medium text-gray-800">{image.name}</span>
          </BreadcrumbItem>
        </Breadcrumb>
        
        <Card className="overflow-hidden">
          <div className="bg-white p-4 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="bg-green-100 p-2 rounded-full mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-lg font-semibold text-gray-800">{image.name}</h1>
                  <p className="text-xs text-gray-500">Adicionado em {formatDate(image.createdAt)} • {formatBytes(image.size)}</p>
                </div>
              </div>
              <Button 
                variant="outline"
                onClick={() => handleDownload(image.path, image.name)}
              >
                <Download className="h-4 w-4 mr-2" />
                Baixar
              </Button>
            </div>
          </div>
          
          <div className="bg-black flex items-center justify-center p-4">
            <img 
              src={getImagePath(image.path)}
              alt={image.name}
              className="max-h-[80vh] max-w-full object-contain"
            />
          </div>
          
          {image.description && (
            <CardContent className="py-4">
              <h3 className="text-sm font-medium text-gray-700 mb-1">Descrição</h3>
              <p className="text-sm text-gray-600">{image.description}</p>
            </CardContent>
          )}
        </Card>
      </div>
    );
  }

  return null;
}