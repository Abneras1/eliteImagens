import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Folder, FileImage } from "lucide-react";
import { formatDate } from "@/lib/utils";

export default function SharedWithMe() {
  const [, navigate] = useLocation();

  const { data: sharedLinks, isLoading, error } = useQuery({ 
    queryKey: ['/api/share'],
  });

  if (isLoading) {
    return (
      <div className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-5 w-16" />
        </div>
        
        <Card>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead><Skeleton className="h-4 w-20" /></TableHead>
                  <TableHead className="hidden sm:table-cell"><Skeleton className="h-4 w-20" /></TableHead>
                  <TableHead className="hidden md:table-cell"><Skeleton className="h-4 w-20" /></TableHead>
                  <TableHead className="text-right"><Skeleton className="h-4 w-20 ml-auto" /></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Array(2).fill(0).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-6 w-40" /></TableCell>
                    <TableCell className="hidden sm:table-cell"><Skeleton className="h-5 w-20" /></TableCell>
                    <TableCell className="hidden md:table-cell"><Skeleton className="h-5 w-20" /></TableCell>
                    <TableCell className="text-right"><Skeleton className="h-8 w-16 ml-auto" /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    );
  }

  if (error || !sharedLinks || sharedLinks.length === 0) {
    return null;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Shared By Me</h2>
        <a href="/" className="text-primary hover:text-primary-dark text-sm">View all</a>
      </div>
      
      <Card>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead className="hidden sm:table-cell">Type</TableHead>
                <TableHead className="hidden md:table-cell">Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sharedLinks.map((link: any) => (
                <TableRow key={link.id}>
                  <TableCell>
                    <div className="flex items-center">
                      {link.folderId ? (
                        <Folder className="h-5 w-5 text-amber-500 mr-2" />
                      ) : (
                        <FileImage className="h-5 w-5 text-green-500 mr-2" />
                      )}
                      <div>
                        <div className="text-sm font-medium text-gray-900 truncate max-w-[200px]">
                          {link.folderName || link.imageName || 'Shared content'}
                        </div>
                        <div className="text-xs text-gray-500">
                          {link.folderId ? 'Folder' : 'Image'}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-sm text-gray-500">
                    {link.folderId ? 'Folder' : 'Image'}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-sm text-gray-500">
                    {formatDate(link.createdAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="link" 
                      className="text-primary hover:text-primary-dark"
                      onClick={() => window.open(link.url, '_blank')}
                    >
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
