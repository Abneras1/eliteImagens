import { useQuery } from "@tanstack/react-query";
import { useApp } from "@/contexts/AppContext";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Eye } from "lucide-react";

export default function RecentlyUpdated() {
  const { setImagePreviewOpen, setCurrentImage } = useApp();
  
  const { data: recentImages, isLoading, error } = useQuery({ 
    queryKey: ['/api/images/recent'],
  });

  if (isLoading) {
    return (
      <div className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-5 w-16" />
        </div>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle><Skeleton className="h-5 w-40" /></CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4">
            {Array(6).fill(0).map((_, i) => (
              <Skeleton key={i} className="aspect-square w-full rounded" />
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error || !recentImages || recentImages.length === 0) {
    return null;
  }

  const folderImages: { [key: string]: any[] } = {};
  
  // Group images by folderId
  recentImages.forEach((image: any) => {
    if (!folderImages[image.folderId]) {
      folderImages[image.folderId] = [];
    }
    folderImages[image.folderId].push(image);
  });

  // Get the first folder (most recent)
  const firstFolderId = Object.keys(folderImages)[0];
  if (!firstFolderId) return null;
  
  const images = folderImages[firstFolderId];
  
  return (
    <div className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Recently Updated</h2>
        <a href="/" className="text-primary hover:text-primary-dark text-sm">View all</a>
      </div>
      
      <Card>
        <CardHeader className="pb-2 border-b">
          <div className="flex justify-between items-center">
            <CardTitle className="text-base">{images[0]?.folderName || 'Images'}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4 p-4">
          {images.slice(0, 6).map((image: any) => (
            <div key={image.id} className="relative group">
              <img 
                src={image.path.startsWith('/uploads') ? image.path : `/uploads/${image.path.split('/').pop()}`} 
                alt={image.name} 
                className="h-24 w-full object-cover rounded"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded">
                <Button 
                  variant="secondary" 
                  size="icon" 
                  className="h-8 w-8"
                  onClick={() => {
                    setCurrentImage(image);
                    setImagePreviewOpen(true);
                  }}
                >
                  <Eye className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
