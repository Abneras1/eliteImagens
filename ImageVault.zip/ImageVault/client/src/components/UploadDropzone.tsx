import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useApp } from "@/contexts/AppContext";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { X, Upload, Image as ImageIcon } from "lucide-react";
import { formatBytes } from "@/lib/utils";
import { MAX_FILE_SIZE, ACCEPTED_IMAGE_TYPES } from "@shared/schema";

const MAX_FILES = 10;

export default function UploadDropzone() {
  const { uploadDialogOpen, setUploadDialogOpen, currentFolderId } = useApp();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      // Criar um FormData para o upload
      const formData = new FormData();
      formData.append("image", file);
      
      // Converter explicitamente para número para evitar erros de tipo
      const folderIdNumber = Number(currentFolderId);
      formData.append("folderId", folderIdNumber.toString());

      const response = await fetch("/api/images/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        // Se a resposta for um JSON com mensagem de erro
        try {
          const errorData = await response.json();
          throw new Error(errorData.message || response.statusText);
        } catch (e) {
          // Se não conseguir parsear como JSON, usar o texto bruto
          const errorText = await response.text();
          throw new Error(errorText || response.statusText);
        }
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/folders/${currentFolderId}/images`] });
      queryClient.invalidateQueries({ queryKey: ['/api/folders'] });
      queryClient.invalidateQueries({ queryKey: ['/api/images/recent'] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao enviar",
        description: error.message || "Ocorreu um erro durante o envio do arquivo.",
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      validateAndAddFiles(selectedFiles);
    }
  };

  const validateAndAddFiles = (selectedFiles: File[]) => {
    // Filter out invalid files
    const validFiles = selectedFiles.filter(file => {
      // Check file type
      if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
        toast({
          title: "Tipo de arquivo inválido",
          description: `${file.name} não é um tipo de imagem suportado. Apenas JPEG e PNG são permitidos.`,
          variant: "destructive",
        });
        return false;
      }
      
      // Check file size
      if (file.size > MAX_FILE_SIZE) {
        toast({
          title: "Arquivo muito grande",
          description: `${file.name} excede o tamanho máximo de arquivo de 5MB.`,
          variant: "destructive",
        });
        return false;
      }
      
      return true;
    });
    
    // Check total files limit
    if (files.length + validFiles.length > MAX_FILES) {
      toast({
        title: "Muitos arquivos",
        description: `Você pode enviar no máximo ${MAX_FILES} arquivos de uma vez.`,
        variant: "destructive",
      });
      // Add only as many files as allowed
      setFiles([...files, ...validFiles.slice(0, MAX_FILES - files.length)]);
    } else {
      setFiles([...files, ...validFiles]);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.dataTransfer.files) {
      validateAndAddFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (files.length === 0) {
      toast({
        title: "Nenhum arquivo selecionado",
        description: "Por favor, selecione pelo menos uma imagem para enviar.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);
    
    const totalFiles = files.length;
    let completedFiles = 0;
    let hasErrors = false;
    
    for (const file of files) {
      try {
        await uploadMutation.mutateAsync(file);
        completedFiles++;
        setUploadProgress(Math.round((completedFiles / totalFiles) * 100));
      } catch (error) {
        hasErrors = true;
        // Continue with next file
        completedFiles++;
        setUploadProgress(Math.round((completedFiles / totalFiles) * 100));
      }
    }
    
    setIsUploading(false);
    
    if (!hasErrors) {
      toast({
        title: "Envio completo",
        description: `${totalFiles} ${totalFiles === 1 ? 'imagem enviada' : 'imagens enviadas'} com sucesso.`,
      });
      setFiles([]);
      setUploadDialogOpen(false);
    } else if (completedFiles > 0) {
      toast({
        title: "Envio parcialmente completo",
        description: `Enviados ${completedFiles} de ${totalFiles} arquivos. Alguns envios falharam.`,
        variant: "default",
      });
    }
  };

  return (
    <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Enviar Imagens</DialogTitle>
        </DialogHeader>
        
        <div
          className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center mb-4"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
        >
          <Upload className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-2 text-sm text-gray-600">
            Arraste e solte imagens aqui, ou clique para navegar
          </p>
          <p className="mt-1 text-xs text-gray-500">
            Formatos suportados: JPEG, PNG. Tamanho máximo: 5MB
          </p>
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept="image/jpeg,image/png"
            multiple
            onChange={handleFileChange}
          />
          <Button
            className="mt-4"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
          >
            Selecionar Arquivos
          </Button>
        </div>
        
        {files.length > 0 && (
          <div className="space-y-2 max-h-40 overflow-auto mb-4">
            {files.map((file, index) => (
              <div key={index} className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <span className="h-9 w-9 flex-shrink-0 rounded bg-gray-200 flex items-center justify-center">
                    <ImageIcon className="h-5 w-5 text-gray-500" />
                  </span>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900 truncate max-w-[180px]">{file.name}</p>
                    <p className="text-xs text-gray-500">{formatBytes(file.size)}</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeFile(index)}
                  disabled={isUploading}
                >
                  <X className="h-5 w-5 text-gray-400" />
                </Button>
              </div>
            ))}
          </div>
        )}
        
        {isUploading && (
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-xs font-medium text-gray-500">Progresso</span>
              <span className="text-xs font-medium text-gray-500">{uploadProgress}%</span>
            </div>
            <Progress value={uploadProgress} className="h-2" />
          </div>
        )}
        
        <DialogFooter className="sm:justify-end">
          <Button
            variant="outline"
            onClick={() => setUploadDialogOpen(false)}
            disabled={isUploading}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleUpload}
            disabled={files.length === 0 || isUploading}
          >
            {isUploading ? "Uploading..." : "Upload"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
