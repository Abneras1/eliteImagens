import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useApp } from "@/contexts/AppContext";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog, 
  DialogContent,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Share2, Download, Trash2, Pencil } from "lucide-react";
import { formatDate } from "@/lib/utils";

export default function ImagePreview() {
  const { 
    imagePreviewOpen, 
    setImagePreviewOpen, 
    currentImage, 
    setCurrentImage,
    setShareDialogOpen,
    setSharedContentType,
    setSharedContentId,
    setShareUrl
  } = useApp();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [description, setDescription] = useState("");

  const updateImageMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PUT", `/api/images/${currentImage?.id}`, { 
        description 
      });
      return res.json();
    },
    onSuccess: (data) => {
      setCurrentImage({ ...currentImage, description: data.description });
      setIsEditing(false);
      toast({
        title: "Description updated",
        description: "Image description has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/folders/${currentImage?.folderId}/images`] });
      queryClient.invalidateQueries({ queryKey: ['/api/images/recent'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating description",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteImageMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/images/${currentImage?.id}`, undefined);
      return res;
    },
    onSuccess: () => {
      setImagePreviewOpen(false);
      setCurrentImage(null);
      toast({
        title: "Image deleted",
        description: "Image has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/folders/${currentImage?.folderId}/images`] });
      queryClient.invalidateQueries({ queryKey: ['/api/images/recent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/folders'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting image",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEdit = () => {
    setDescription(currentImage?.description || "");
    setIsEditing(true);
  };

  const handleSave = () => {
    updateImageMutation.mutate();
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this image? This action cannot be undone.")) {
      deleteImageMutation.mutate();
    }
  };

  const handleShare = () => {
    setShareUrl("");
    setSharedContentType("image");
    setSharedContentId(currentImage?.id);
    setImagePreviewOpen(false);
    setShareDialogOpen(true);
  };

  const handleDownload = () => {
    if (currentImage) {
      const link = document.createElement('a');
      link.href = currentImage.path.startsWith('/uploads') 
        ? currentImage.path 
        : `/uploads/${currentImage.path.split('/').pop()}`;
      link.download = currentImage.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  if (!currentImage) return null;

  return (
    <Dialog open={imagePreviewOpen} onOpenChange={setImagePreviewOpen}>
      <DialogContent className="max-w-4xl p-0 overflow-hidden">
        <div className="relative w-full h-[70vh] bg-black flex items-center justify-center">
          <img 
            src={currentImage.path.startsWith('/uploads') 
              ? currentImage.path 
              : `/uploads/${currentImage.path.split('/').pop()}`} 
            alt={currentImage.name}
            className="max-h-full max-w-full object-contain"
          />
        </div>
        
        <div className="p-4 bg-white">
          <div className="flex flex-col md:flex-row justify-between md:items-center mb-4">
            <div>
              <h3 className="text-lg font-medium text-gray-900">{currentImage.name}</h3>
              <p className="text-sm text-gray-500">Added: {formatDate(currentImage.createdAt)}</p>
            </div>
            
            <div className="flex mt-3 md:mt-0 space-x-3">
              <Button variant="outline" size="sm" onClick={handleDownload}>
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </Button>
              <Button variant="outline" size="sm" onClick={handleDelete}>
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
            </div>
          </div>
          
          {isEditing ? (
            <div>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add a description..."
                className="mb-2"
              />
              <div className="flex justify-end space-x-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setIsEditing(false)}
                >
                  Cancel
                </Button>
                <Button 
                  size="sm"
                  onClick={handleSave}
                  disabled={updateImageMutation.isPending}
                >
                  {updateImageMutation.isPending ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          ) : (
            <div 
              className="text-sm text-gray-700 min-h-[60px] flex justify-between"
            >
              <div>{currentImage.description || "No description"}</div>
              <Button variant="ghost" size="sm" onClick={handleEdit}>
                <Pencil className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
