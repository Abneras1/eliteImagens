import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import FolderCard from "./FolderCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useApp } from "@/contexts/AppContext";
import { Search, Plus, FolderPlus } from "lucide-react";

export default function FolderGrid() {
  const [searchQuery, setSearchQuery] = useState("");
  const { setCreateFolderOpen } = useApp();

  const { data: folders, isLoading, error } = useQuery({ 
    queryKey: ['/api/folders'],
  });

  if (isLoading) {
    return (
      <div>
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 space-y-4 sm:space-y-0">
          <h2 className="text-2xl font-semibold text-gray-800">My Folders</h2>
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
            <div className="relative">
              <Skeleton className="h-10 w-full sm:w-64" />
            </div>
            <Skeleton className="h-10 w-full sm:w-40" />
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-10">
          {Array(4).fill(0).map((_, i) => (
            <Skeleton key={i} className="h-64 w-full" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 text-red-500">
        Error loading folders: {(error as Error).message}
      </div>
    );
  }

  const filteredFolders = folders.filter((folder: any) => 
    folder.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 space-y-4 sm:space-y-0">
        <h2 className="text-2xl font-semibold text-gray-800">My Folders</h2>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Search folders..."
              className="pl-10 pr-4 py-2 w-full sm:w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button onClick={() => setCreateFolderOpen(true)}>
            <Plus className="h-5 w-5 mr-2" />
            Create Folder
          </Button>
        </div>
      </div>

      {filteredFolders.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center mb-10">
          <FolderPlus className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">No folders found</h3>
          <p className="text-gray-500 mb-4">
            {searchQuery ? "No folders match your search criteria." : "Get started by creating your first folder."}
          </p>
          {!searchQuery && (
            <Button onClick={() => setCreateFolderOpen(true)}>
              <Plus className="h-5 w-5 mr-2" />
              Create Folder
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-10">
          {filteredFolders.map((folder: any) => (
            <FolderCard 
              key={folder.id} 
              folder={folder} 
            />
          ))}
        </div>
      )}
    </div>
  );
}
