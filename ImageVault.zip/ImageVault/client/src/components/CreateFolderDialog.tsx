import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useApp } from "@/contexts/AppContext";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function CreateFolderDialog() {
  const { createFolderOpen, setCreateFolderOpen } = useApp();
  const [folderName, setFolderName] = useState("");
  const { toast } = useToast();

  const createFolderMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/folders", { name: folderName });
      return res.json();
    },
    onSuccess: () => {
      setFolderName("");
      setCreateFolderOpen(false);
      toast({
        title: "Pasta criada",
        description: "Sua pasta foi criada com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/folders'] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao criar pasta",
        description: error.message || "Algo deu errado. Por favor, tente novamente.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (folderName.trim() === "") {
      toast({
        title: "Nome da pasta obrigatório",
        description: "Por favor, digite um nome para sua pasta.",
        variant: "destructive",
      });
      return;
    }
    createFolderMutation.mutate();
  };

  return (
    <Dialog open={createFolderOpen} onOpenChange={setCreateFolderOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Criar Nova Pasta</DialogTitle>
          <DialogDescription>
            Digite um nome para sua nova pasta.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="folder-name">Nome da Pasta</Label>
              <Input
                id="folder-name"
                placeholder="Digite o nome da pasta"
                value={folderName}
                onChange={(e) => setFolderName(e.target.value)}
                autoComplete="off"
              />
            </div>
          </div>
          <DialogFooter className="sm:justify-end">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setCreateFolderOpen(false)}
            >
              Cancelar
            </Button>
            <Button 
              type="submit"
              disabled={createFolderMutation.isPending}
            >
              {createFolderMutation.isPending ? "Criando..." : "Criar Pasta"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
