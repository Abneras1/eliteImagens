import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useApp } from "@/contexts/AppContext";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Folder, MoreVertical, Pencil, Trash2, Share2, Upload } from "lucide-react";
import { formatDate } from "@/lib/utils";

interface FolderCardProps {
  folder: {
    id: number;
    name: string;
    imageCount: number;
    updatedAt: string;
  };
  thumbnails?: string[];
}

export default function FolderCard({ folder, thumbnails = [] }: FolderCardProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { 
    setShareDialogOpen, 
    setSharedContentType, 
    setSharedContentId,
    setShareUrl,
    setUploadDialogOpen,
    setCurrentFolderId
  } = useApp();
  
  const [isRenaming, setIsRenaming] = useState(false);
  const [newName, setNewName] = useState(folder.name);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const renameFolderMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PUT", `/api/folders/${folder.id}`, { name: newName });
      return res.json();
    },
    onSuccess: () => {
      setIsRenaming(false);
      toast({
        title: "Folder renamed",
        description: "Your folder has been renamed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/folders'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error renaming folder",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteFolderMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/folders/${folder.id}`, undefined);
      return res;
    },
    onSuccess: () => {
      setDeleteDialogOpen(false);
      toast({
        title: "Folder deleted",
        description: "Your folder and all its contents have been deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/folders'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting folder",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleShare = () => {
    setShareUrl("");
    setSharedContentType("folder");
    setSharedContentId(folder.id);
    setShareDialogOpen(true);
  };

  const handleUpload = () => {
    setCurrentFolderId(folder.id);
    setUploadDialogOpen(true);
  };

  const handleRename = (e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim() === "") {
      toast({
        title: "Folder name required",
        description: "Please enter a name for your folder.",
        variant: "destructive",
      });
      return;
    }
    renameFolderMutation.mutate();
  };

  const handleDelete = () => {
    deleteFolderMutation.mutate();
  };

  const navigateToFolder = () => {
    navigate(`/folders/${folder.id}`);
  };

  return (
    <>
      <Card className="overflow-hidden hover:shadow-md transition-shadow border border-gray-200">
        <div className="relative">
          {folder.imageCount > 0 && thumbnails.length > 0 ? (
            <div className="grid grid-cols-2 grid-rows-2 gap-0.5 h-48 bg-gray-100">
              {thumbnails.slice(0, 3).map((url, idx) => (
                <div key={idx} className="bg-blue-50 overflow-hidden">
                  <img src={url} className="h-full w-full object-cover" alt="Thumbnail" />
                </div>
              ))}
              {thumbnails.length > 3 ? (
                <div className="bg-blue-50 overflow-hidden flex items-center justify-center">
                  <span className="text-gray-600 font-medium">+{folder.imageCount - 3}</span>
                </div>
              ) : thumbnails.length === 3 ? (
                <div className="bg-blue-50 overflow-hidden"></div>
              ) : null}
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center bg-gray-100">
              <div className="text-center p-6">
                <Folder className="h-16 w-16 text-gray-300 mx-auto" />
                <p className="mt-1 text-sm text-gray-500">Empty folder</p>
              </div>
            </div>
          )}

          <div className="absolute top-2 right-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full bg-white h-8 w-8">
                  <MoreVertical className="h-5 w-5 text-gray-500" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={navigateToFolder}>
                  Open
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleUpload}>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Images
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleShare}>
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setIsRenaming(true)}>
                  <Pencil className="h-4 w-4 mr-2" />
                  Rename
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => setDeleteDialogOpen(true)}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <div className="p-4" onClick={navigateToFolder} style={{ cursor: 'pointer' }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Folder className="h-5 w-5 text-amber-500 mr-2" />
              <h3 className="font-medium text-gray-800">{folder.name}</h3>
            </div>
            <span className="text-xs text-gray-500">{folder.imageCount} {folder.imageCount === 1 ? 'item' : 'items'}</span>
          </div>
          <div className="mt-3 flex items-center justify-between">
            <span className="text-xs text-gray-500">Updated {formatDate(folder.updatedAt)}</span>
            <Button 
              variant="ghost" 
              size="sm"
              className="text-primary hover:text-primary-dark p-0 h-auto"
              onClick={(e) => {
                e.stopPropagation();
                handleShare();
              }}
            >
              <Share2 className="h-4 w-4 mr-1" />
              Share
            </Button>
          </div>
        </div>
      </Card>

      {/* Rename Dialog */}
      <Dialog open={isRenaming} onOpenChange={setIsRenaming}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Rename Folder</DialogTitle>
            <DialogDescription>
              Enter a new name for your folder.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRename}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="folder-name">Folder Name</Label>
                <Input
                  id="folder-name"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  autoComplete="off"
                />
              </div>
            </div>
            <DialogFooter className="sm:justify-end">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsRenaming(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={renameFolderMutation.isPending}
              >
                {renameFolderMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Folder</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this folder? This will permanently remove the folder and all of its contents.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="sm:justify-end">
            <Button 
              variant="outline" 
              onClick={() => setDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDelete}
              disabled={deleteFolderMutation.isPending}
            >
              {deleteFolderMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
