import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { useApp } from "@/contexts/AppContext";
import { apiRequest } from "@/lib/queryClient";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Copy, Facebook, Twitter, Linkedin, MessageSquare } from "lucide-react";

export default function ShareDialog() {
  const { 
    shareDialogOpen, 
    setShareDialogOpen, 
    shareUrl, 
    setShareUrl,
    sharedContentType,
    sharedContentId,
    copyToClipboard
  } = useApp();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const createShareLinkMutation = useMutation({
    mutationFn: async () => {
      let payload = {};
      if (sharedContentType === 'folder') {
        payload = { folderId: sharedContentId };
      } else if (sharedContentType === 'image') {
        payload = { imageId: sharedContentId };
      }

      const res = await apiRequest("POST", "/api/share", payload);
      return res.json();
    },
    onSuccess: (data) => {
      setShareUrl(data.url);
      setIsLoading(false);
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao criar link de compartilhamento",
        description: error.message || "Algo deu errado. Por favor, tente novamente.",
        variant: "destructive",
      });
      setIsLoading(false);
    },
  });

  useEffect(() => {
    if (shareDialogOpen && !shareUrl && sharedContentId) {
      setIsLoading(true);
      createShareLinkMutation.mutate();
    }
  }, [shareDialogOpen, shareUrl, sharedContentId]);

  const handleCopy = () => {
    copyToClipboard(shareUrl);
  };

  return (
    <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Compartilhar</DialogTitle>
          <DialogDescription>
            Qualquer pessoa com este link pode visualizar:
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-center space-x-2 mb-4">
          <div className="grid flex-1 gap-2">
            <Input
              value={shareUrl}
              readOnly
              className="bg-gray-50"
            />
          </div>
          <Button 
            size="icon" 
            className="px-3" 
            onClick={handleCopy}
            disabled={isLoading}
          >
            <Copy className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="border-t border-gray-200 pt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-3">Compartilhar via:</h4>
          <div className="grid grid-cols-4 gap-3">
            <Button 
              variant="outline" 
              className="flex flex-col items-center justify-center h-16 p-2"
              disabled={isLoading}
              onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank')}
            >
              <Facebook className="h-5 w-5 text-blue-600 mb-1" />
              <span className="text-xs">Facebook</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex flex-col items-center justify-center h-16 p-2"
              disabled={isLoading}
              onClick={() => window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}`, '_blank')}
            >
              <Twitter className="h-5 w-5 text-blue-400 mb-1" />
              <span className="text-xs">Twitter</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex flex-col items-center justify-center h-16 p-2"
              disabled={isLoading}
              onClick={() => window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareUrl)}`, '_blank')}
            >
              <MessageSquare className="h-5 w-5 text-green-500 mb-1" />
              <span className="text-xs">WhatsApp</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex flex-col items-center justify-center h-16 p-2"
              disabled={isLoading}
              onClick={() => window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`, '_blank')}
            >
              <Linkedin className="h-5 w-5 text-blue-700 mb-1" />
              <span className="text-xs">LinkedIn</span>
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
