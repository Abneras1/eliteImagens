import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useToast } from "@/hooks/use-toast";

interface AppContextProps {
  createFolderOpen: boolean;
  setCreateFolderOpen: (open: boolean) => void;
  shareDialogOpen: boolean;
  setShareDialogOpen: (open: boolean) => void;
  shareUrl: string;
  setShareUrl: (url: string) => void;
  sharedContentType: 'folder' | 'image' | null;
  setSharedContentType: (type: 'folder' | 'image' | null) => void;
  sharedContentId: number | null;
  setSharedContentId: (id: number | null) => void;
  imagePreviewOpen: boolean;
  setImagePreviewOpen: (open: boolean) => void;
  currentImage: any | null;
  setCurrentImage: (image: any | null) => void;
  uploadDialogOpen: boolean;
  setUploadDialogOpen: (open: boolean) => void;
  currentFolderId: number | null;
  setCurrentFolderId: (id: number | null) => void;
  copyToClipboard: (text: string) => void;
}

const AppContext = createContext<AppContextProps | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [createFolderOpen, setCreateFolderOpen] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [shareUrl, setShareUrl] = useState("");
  const [sharedContentType, setSharedContentType] = useState<'folder' | 'image' | null>(null);
  const [sharedContentId, setSharedContentId] = useState<number | null>(null);
  const [imagePreviewOpen, setImagePreviewOpen] = useState(false);
  const [currentImage, setCurrentImage] = useState<any | null>(null);
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [currentFolderId, setCurrentFolderId] = useState<number | null>(null);
  
  const { toast } = useToast();
  
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Link copied to clipboard!",
        description: "You can now share it with others.",
      });
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <AppContext.Provider
      value={{
        createFolderOpen,
        setCreateFolderOpen,
        shareDialogOpen,
        setShareDialogOpen,
        shareUrl,
        setShareUrl,
        sharedContentType,
        setSharedContentType,
        sharedContentId,
        setSharedContentId,
        imagePreviewOpen,
        setImagePreviewOpen,
        currentImage,
        setCurrentImage,
        uploadDialogOpen,
        setUploadDialogOpen,
        currentFolderId,
        setCurrentFolderId,
        copyToClipboard,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
};
