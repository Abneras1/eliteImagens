import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Folders
export const folders = pgTable("folders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertFolderSchema = createInsertSchema(folders).pick({
  name: true,
  userId: true,
});

export type InsertFolder = z.infer<typeof insertFolderSchema>;
export type Folder = typeof folders.$inferSelect;

// Images
export const images = pgTable("images", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  path: text("path").notNull(),
  size: integer("size").notNull(), // in bytes
  folderId: integer("folder_id").notNull(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertImageSchema = createInsertSchema(images).pick({
  name: true, 
  description: true,
  path: true,
  size: true,
  folderId: true,
  userId: true,
});

export type InsertImage = z.infer<typeof insertImageSchema>;
export type Image = typeof images.$inferSelect;

// Shared links
export const sharedLinks = pgTable("shared_links", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  folderId: integer("folder_id"),
  imageId: integer("image_id"),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
});

export const insertSharedLinkSchema = createInsertSchema(sharedLinks).pick({
  token: true,
  folderId: true,
  imageId: true,
  userId: true,
  expiresAt: true,
});

export type InsertSharedLink = z.infer<typeof insertSharedLinkSchema>;
export type SharedLink = typeof sharedLinks.$inferSelect;

// Validation schemas for the API
export const createFolderSchema = z.object({
  name: z.string().min(1, "Folder name is required").max(50, "Folder name must be less than 50 characters"),
});

export const uploadImageSchema = z.object({
  folderId: z.number().positive("Folder ID is required")
});

export const updateImageSchema = z.object({
  description: z.string().max(500, "Description must be less than 500 characters").optional(),
});

export const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png"];
