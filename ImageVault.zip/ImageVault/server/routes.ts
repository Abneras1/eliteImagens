import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import { nanoid } from 'nanoid';
import { 
  createFolderSchema, 
  updateImageSchema,
  uploadImageSchema,
  MAX_FILE_SIZE,
  ACCEPTED_IMAGE_TYPES
} from '@shared/schema';

// Set up storage for uploads
const uploadDir = path.join(process.cwd(), 'uploads');

// Ensure the uploads directory exists
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer
const storage2 = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniquePrefix = nanoid(10);
    cb(null, uniquePrefix + '-' + file.originalname);
  }
});

const upload = multer({
  storage: storage2,
  limits: {
    fileSize: MAX_FILE_SIZE
  },
  fileFilter: (req, file, cb) => {
    if (ACCEPTED_IMAGE_TYPES.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG and PNG are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);

  // Get all folders for a user
  app.get('/api/folders', async (req, res) => {
    try {
      // In a real app, this would use the authenticated user's ID
      const userId = 1; // Using demo user
      const folders = await storage.getFolders(userId);
      
      // Add image count to each folder
      const foldersWithCounts = await Promise.all(
        folders.map(async (folder) => {
          const images = await storage.getImages(folder.id);
          return {
            ...folder,
            imageCount: images.length
          };
        })
      );
      
      res.json(foldersWithCounts);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching folders' });
    }
  });

  // Get a specific folder
  app.get('/api/folders/:id', async (req, res) => {
    try {
      const folderId = parseInt(req.params.id);
      const folder = await storage.getFolder(folderId);
      
      if (!folder) {
        return res.status(404).json({ message: 'Folder not found' });
      }
      
      res.json(folder);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching folder' });
    }
  });

  // Create a new folder
  app.post('/api/folders', async (req, res) => {
    try {
      const parseResult = createFolderSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ message: parseResult.error.errors[0].message });
      }
      
      // In a real app, this would use the authenticated user's ID
      const userId = 1; // Using demo user
      
      const newFolder = await storage.createFolder({
        name: parseResult.data.name,
        userId
      });
      
      res.status(201).json(newFolder);
    } catch (error) {
      res.status(500).json({ message: 'Error creating folder' });
    }
  });

  // Update a folder
  app.put('/api/folders/:id', async (req, res) => {
    try {
      const folderId = parseInt(req.params.id);
      const parseResult = createFolderSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ message: parseResult.error.errors[0].message });
      }
      
      const updatedFolder = await storage.updateFolder(folderId, parseResult.data.name);
      
      if (!updatedFolder) {
        return res.status(404).json({ message: 'Folder not found' });
      }
      
      res.json(updatedFolder);
    } catch (error) {
      res.status(500).json({ message: 'Error updating folder' });
    }
  });

  // Delete a folder
  app.delete('/api/folders/:id', async (req, res) => {
    try {
      const folderId = parseInt(req.params.id);
      const success = await storage.deleteFolder(folderId);
      
      if (!success) {
        return res.status(404).json({ message: 'Folder not found' });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: 'Error deleting folder' });
    }
  });

  // Get all images in a folder
  app.get('/api/folders/:id/images', async (req, res) => {
    try {
      const folderId = parseInt(req.params.id);
      const folder = await storage.getFolder(folderId);
      
      if (!folder) {
        return res.status(404).json({ message: 'Folder not found' });
      }
      
      const images = await storage.getImages(folderId);
      res.json(images);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching images' });
    }
  });

  // Upload an image to a folder
  app.post('/api/images/upload', upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No image file provided' });
      }

      // Converter o folderId para número antes da validação
      if (req.body.folderId) {
        req.body.folderId = Number(req.body.folderId);
      }

      const parseResult = uploadImageSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        // Remove the uploaded file if validation fails
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ message: parseResult.error.errors[0].message });
      }

      const { folderId } = parseResult.data;
      const folder = await storage.getFolder(folderId);
      
      if (!folder) {
        // Remove the uploaded file if folder doesn't exist
        fs.unlinkSync(req.file.path);
        return res.status(404).json({ message: 'Folder not found' });
      }

      // In a real app, this would use the authenticated user's ID
      const userId = 1; // Using demo user
      
      const newImage = await storage.createImage({
        name: req.file.originalname,
        description: '',
        path: req.file.path,
        size: req.file.size,
        folderId: Number(folderId),
        userId
      });
      
      res.status(201).json(newImage);
    } catch (error) {
      if (req.file) {
        // Remove the uploaded file on error
        fs.unlinkSync(req.file.path);
      }
      res.status(500).json({ message: 'Error uploading image' });
    }
  });

  // Update image description
  app.put('/api/images/:id', async (req, res) => {
    try {
      const imageId = parseInt(req.params.id);
      const parseResult = updateImageSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ message: parseResult.error.errors[0].message });
      }
      
      const updatedImage = await storage.updateImage(imageId, parseResult.data.description || '');
      
      if (!updatedImage) {
        return res.status(404).json({ message: 'Image not found' });
      }
      
      res.json(updatedImage);
    } catch (error) {
      res.status(500).json({ message: 'Error updating image' });
    }
  });

  // Delete an image
  app.delete('/api/images/:id', async (req, res) => {
    try {
      const imageId = parseInt(req.params.id);
      const image = await storage.getImage(imageId);
      
      if (!image) {
        return res.status(404).json({ message: 'Image not found' });
      }
      
      // Delete the file from the filesystem
      if (fs.existsSync(image.path)) {
        fs.unlinkSync(image.path);
      }
      
      const success = await storage.deleteImage(imageId);
      
      if (!success) {
        return res.status(500).json({ message: 'Failed to delete image' });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: 'Error deleting image' });
    }
  });

  // Serve uploaded images
  app.get('/uploads/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(uploadDir, filename);
    
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).json({ message: 'Image not found' });
    }
  });

  // Get recently updated images
  app.get('/api/images/recent', async (req, res) => {
    try {
      // In a real app, this would use the authenticated user's ID
      const userId = 1; // Using demo user
      const limit = parseInt(req.query.limit as string) || 10;
      
      const recentImages = await storage.getRecentImages(userId, limit);
      res.json(recentImages);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching recent images' });
    }
  });

  // Create a shared link
  app.post('/api/share', async (req, res) => {
    try {
      const { folderId, imageId } = req.body;
      
      if (!folderId && !imageId) {
        return res.status(400).json({ message: 'Either folderId or imageId must be provided' });
      }
      
      if (folderId && imageId) {
        return res.status(400).json({ message: 'Only one of folderId or imageId should be provided' });
      }
      
      // In a real app, this would use the authenticated user's ID
      const userId = 1; // Using demo user
      
      // Check if folder or image exists
      if (folderId) {
        const folder = await storage.getFolder(Number(folderId));
        if (!folder) {
          return res.status(404).json({ message: 'Folder not found' });
        }
      }
      
      if (imageId) {
        const image = await storage.getImage(Number(imageId));
        if (!image) {
          return res.status(404).json({ message: 'Image not found' });
        }
      }
      
      const sharedLink = await storage.createSharedLink({
        folderId: folderId ? Number(folderId) : undefined,
        imageId: imageId ? Number(imageId) : undefined,
        userId,
        expiresAt: undefined
      });
      
      res.status(201).json({
        ...sharedLink,
        url: `${req.protocol}://${req.get('host')}/share/${sharedLink.token}`
      });
    } catch (error) {
      res.status(500).json({ message: 'Error creating shared link' });
    }
  });

  // Get shared links for current user
  app.get('/api/share', async (req, res) => {
    try {
      // In a real app, this would use the authenticated user's ID
      const userId = 1; // Using demo user
      
      const sharedLinks = await storage.getSharedLinks(userId);
      const linksWithUrl = sharedLinks.map(link => ({
        ...link,
        url: `${req.protocol}://${req.get('host')}/share/${link.token}`
      }));
      
      res.json(linksWithUrl);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching shared links' });
    }
  });

  // Get shared content
  app.get('/api/share/:token', async (req, res) => {
    try {
      const token = req.params.token;
      const sharedLink = await storage.getSharedLink(token);
      
      if (!sharedLink) {
        return res.status(404).json({ message: 'Shared link not found or expired' });
      }
      
      // Check if expired
      if (sharedLink.expiresAt && new Date() > sharedLink.expiresAt) {
        return res.status(410).json({ message: 'Shared link has expired' });
      }
      
      if (sharedLink.folderId) {
        const folder = await storage.getFolder(sharedLink.folderId);
        if (!folder) {
          return res.status(404).json({ message: 'Shared folder not found' });
        }
        
        const images = await storage.getImages(folder.id);
        return res.json({
          type: 'folder',
          data: {
            folder,
            images
          }
        });
      } else if (sharedLink.imageId) {
        const image = await storage.getImage(sharedLink.imageId);
        if (!image) {
          return res.status(404).json({ message: 'Shared image not found' });
        }
        
        return res.json({
          type: 'image',
          data: image
        });
      } else {
        return res.status(400).json({ message: 'Invalid shared link' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Error fetching shared content' });
    }
  });

  // Delete a shared link
  app.delete('/api/share/:id', async (req, res) => {
    try {
      const linkId = parseInt(req.params.id);
      const success = await storage.deleteSharedLink(linkId);
      
      if (!success) {
        return res.status(404).json({ message: 'Shared link not found' });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: 'Error deleting shared link' });
    }
  });

  return httpServer;
}
