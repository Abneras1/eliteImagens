import { nanoid } from "nanoid";
import { 
  users, type User, type InsertUser,
  folders, type Folder, type InsertFolder,
  images, type Image, type InsertImage,
  sharedLinks, type SharedLink, type InsertSharedLink
} from "@shared/schema";

// Modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Folder methods
  getFolders(userId: number): Promise<Folder[]>;
  getFolder(id: number): Promise<Folder | undefined>;
  createFolder(folder: InsertFolder): Promise<Folder>;
  updateFolder(id: number, name: string): Promise<Folder | undefined>;
  deleteFolder(id: number): Promise<boolean>;

  // Image methods
  getImages(folderId: number): Promise<Image[]>;
  getImage(id: number): Promise<Image | undefined>;
  createImage(image: InsertImage): Promise<Image>;
  updateImage(id: number, description: string): Promise<Image | undefined>;
  deleteImage(id: number): Promise<boolean>;
  getRecentImages(userId: number, limit: number): Promise<Image[]>;

  // Shared link methods
  createSharedLink(link: Omit<InsertSharedLink, "token">): Promise<SharedLink>;
  getSharedLink(token: string): Promise<SharedLink | undefined>;
  getSharedLinks(userId: number): Promise<SharedLink[]>;
  deleteSharedLink(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private folders: Map<number, Folder>;
  private images: Map<number, Image>;
  private sharedLinks: Map<number, SharedLink>;
  private userId: number;
  private folderId: number;
  private imageId: number;
  private sharedLinkId: number;

  constructor() {
    this.users = new Map();
    this.folders = new Map();
    this.images = new Map();
    this.sharedLinks = new Map();
    this.userId = 1;
    this.folderId = 1;
    this.imageId = 1;
    this.sharedLinkId = 1;

    // Create a demo user
    this.createUser({
      username: "demo",
      password: "password",
    });

    // Create some sample folders for the demo user
    this.createFolder({
      name: "Vacation Photos",
      userId: 1,
    });

    this.createFolder({
      name: "Architecture",
      userId: 1,
    });

    this.createFolder({
      name: "Nature",
      userId: 1,
    });

    this.createFolder({
      name: "New Project",
      userId: 1,
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Folder methods
  async getFolders(userId: number): Promise<Folder[]> {
    return Array.from(this.folders.values()).filter(
      (folder) => folder.userId === userId
    );
  }

  async getFolder(id: number): Promise<Folder | undefined> {
    return this.folders.get(id);
  }

  async createFolder(insertFolder: InsertFolder): Promise<Folder> {
    const id = this.folderId++;
    const now = new Date();
    const folder: Folder = { 
      ...insertFolder, 
      id,
      createdAt: now,
      updatedAt: now
    };
    this.folders.set(id, folder);
    return folder;
  }

  async updateFolder(id: number, name: string): Promise<Folder | undefined> {
    const folder = this.folders.get(id);
    if (!folder) return undefined;

    const updatedFolder = { 
      ...folder, 
      name,
      updatedAt: new Date()
    };
    this.folders.set(id, updatedFolder);
    return updatedFolder;
  }

  async deleteFolder(id: number): Promise<boolean> {
    // Delete all images in this folder
    const folderImages = Array.from(this.images.values()).filter(
      (image) => image.folderId === id
    );
    
    for (const image of folderImages) {
      await this.deleteImage(image.id);
    }

    // Delete folder
    return this.folders.delete(id);
  }

  // Image methods
  async getImages(folderId: number): Promise<Image[]> {
    return Array.from(this.images.values()).filter(
      (image) => image.folderId === folderId
    );
  }

  async getImage(id: number): Promise<Image | undefined> {
    return this.images.get(id);
  }

  async createImage(insertImage: InsertImage): Promise<Image> {
    const id = this.imageId++;
    const now = new Date();
    const image: Image = { 
      ...insertImage, 
      id,
      createdAt: now,
      updatedAt: now
    };
    this.images.set(id, image);

    // Update the folder's updatedAt timestamp
    const folder = this.folders.get(image.folderId);
    if (folder) {
      this.folders.set(folder.id, { ...folder, updatedAt: now });
    }

    return image;
  }

  async updateImage(id: number, description: string): Promise<Image | undefined> {
    const image = this.images.get(id);
    if (!image) return undefined;

    const updatedImage = { 
      ...image, 
      description,
      updatedAt: new Date()
    };
    this.images.set(id, updatedImage);
    return updatedImage;
  }

  async deleteImage(id: number): Promise<boolean> {
    // Delete any shared links for this image
    const imageLinks = Array.from(this.sharedLinks.values()).filter(
      (link) => link.imageId === id
    );
    
    for (const link of imageLinks) {
      this.sharedLinks.delete(link.id);
    }
    
    return this.images.delete(id);
  }

  async getRecentImages(userId: number, limit: number): Promise<Image[]> {
    return Array.from(this.images.values())
      .filter((image) => image.userId === userId)
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())
      .slice(0, limit);
  }

  // Shared link methods
  async createSharedLink(link: Omit<InsertSharedLink, "token">): Promise<SharedLink> {
    const id = this.sharedLinkId++;
    const token = nanoid(10);
    const now = new Date();
    
    const sharedLink: SharedLink = {
      ...link,
      id,
      token,
      createdAt: now
    };
    
    this.sharedLinks.set(id, sharedLink);
    return sharedLink;
  }

  async getSharedLink(token: string): Promise<SharedLink | undefined> {
    return Array.from(this.sharedLinks.values()).find(
      (link) => link.token === token
    );
  }

  async getSharedLinks(userId: number): Promise<SharedLink[]> {
    return Array.from(this.sharedLinks.values()).filter(
      (link) => link.userId === userId
    );
  }

  async deleteSharedLink(id: number): Promise<boolean> {
    return this.sharedLinks.delete(id);
  }
}

export const storage = new MemStorage();
